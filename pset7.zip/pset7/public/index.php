<?php

    // configuration
    require("../includes/config.php"); 

    $rows = query("SELECT * FROM portfolio WHERE id = ?", $_SESSION["id"]);

    $stocks = []; 
    $worth = 0.0;
    foreach ($rows as $row) {
		$stock = lookup($row["symbol"]); 
		if ($stock !== false)
		{
        	$stocks[] = [
            	"name" => $stock["name"],
            	"price" => $stock["price"],
            	"shares" => $row["shares"],
            	"symbol" => $row["symbol"]
			]; 
            $worth = $worth + $row["shares"] * $stock["price"];
		}
	}
	$cash = query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"])[0]["cash"];

    //dump([$cash, $worth]);

    $worth = $worth + $cash;

    // render portfolio
    render("portfolio.php", ["title" => "Portfolio", "stocks" => $stocks, "cash" => $cash, "worth" => $worth]);



?>
