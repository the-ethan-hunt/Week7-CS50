<p class="lead text-danger">
    Sorry!
</p>
<p class="text-danger">
    <?= htmlspecialchars($message) ?>
</p>
<br>
<form action="javascript:history.go(-1);" method="post">
    <fieldset>
        <div class="form-group">
            <button type="submit" class="btn btn-danger">Back</button>
        </div>
    </fieldset>
</form>
