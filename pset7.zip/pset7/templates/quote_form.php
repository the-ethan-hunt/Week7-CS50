<form action="quote.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autofocus class="form-control" name="symbol" placeholder="Enter a stock symbol" type="text"/>
        </div>
    </fieldset>
</form>

